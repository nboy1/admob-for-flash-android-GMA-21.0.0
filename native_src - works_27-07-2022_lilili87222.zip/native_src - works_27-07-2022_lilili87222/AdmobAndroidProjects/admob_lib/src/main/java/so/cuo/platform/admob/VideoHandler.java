package so.cuo.platform.admob;
import android.app.Activity;
import android.util.Log;

import androidx.annotation.NonNull;

import com.adobe.fre.FREContext;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class VideoHandler {
    private FREContext context;
    private RewardedAd rewardedVideoAd;
    public void setContext(FREContext ctx) {
        this.context = ctx;
    }
    public boolean isVideoReady() {
        return this.rewardedVideoAd != null;
    }
   public void loadVideo(String rewardedAdID, String param) {
       if (rewardedVideoAd == null) {
            RewardedAd.load(
                    context.getActivity(),
                    rewardedAdID,
                    BannerHandler.getRequest(param),
                    new RewardedAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull RewardedAd Ad) {
                            rewardedVideoAd = Ad;
                            super.onAdLoaded(rewardedVideoAd);
                            context.dispatchStatusEventAsync(AdEvent.onVideoReceive, "FULL_ADMOB_LEVEL");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            rewardedVideoAd = null;
                            super.onAdFailedToLoad(loadAdError);
                            context.dispatchStatusEventAsync(AdEvent.onVideoLoadFail,"FULL_ADMOB_LEVEL");
                        }
                    });


        }


   }



      //  }







    void showVideo() {

        if (rewardedVideoAd != null) {

       rewardedVideoAd.setFullScreenContentCallback(
                new FullScreenContentCallback() {
                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when ad is shown.

                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when ad fails to show.

                        rewardedVideoAd = null;
                        super.onAdFailedToShowFullScreenContent(adError);
                        context.dispatchStatusEventAsync(AdEvent.onVideoLoadFail, "FULL_ADMOB_LEVEL");
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when ad is dismissed.
                        // Don't forget to set the ad reference to null so you
                        // don't show the ad a second time.
                        rewardedVideoAd = null;
                        super.onAdDismissedFullScreenContent( );
                        context.dispatchStatusEventAsync(AdEvent.onVideoClosed, "FULL_ADMOB_LEVEL");
                    }
                });
        rewardedVideoAd.show(context.getActivity(),
                new OnUserEarnedRewardListener() {
                    @Override
                    public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                        // Handle the reward.

                        int rewardAmount = rewardItem.getAmount();
                        String rewardType = rewardItem.getType();


                        context.dispatchStatusEventAsync(AdEvent.onVideoCompleted, "FULL_ADMOB_LEVEL");
                  }

                });


    }
}
}
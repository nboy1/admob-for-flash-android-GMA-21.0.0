package so.cuo.platform.admob;

import android.widget.Toast;

import androidx.annotation.NonNull;

import com.adobe.fre.FREContext;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class InterstitialHandler {
	private FREContext context;
	public InterstitialAd interstitial;

	public void setContext(FREContext ctx) {
		this.context = ctx;
	}
	public boolean isInterstitialReady() {
		return this.interstitial != null;
	}

	public void loadInterstitial(String admobID, String param) {

		InterstitialAd.load(context.getActivity(), admobID, BannerHandler.getRequest(param),
				new InterstitialAdLoadCallback() {
					@Override
					public void onAdLoaded(@NonNull InterstitialAd Ad) {
						interstitial = Ad;
						super.onAdLoaded(interstitial);
						context.dispatchStatusEventAsync(AdEvent.onInterstitialReceive, "FULL_ADMOB_LEVEL");
					}

					@Override
					public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
						// Handle the error

						interstitial = null;
						super.onAdFailedToLoad(loadAdError);
						context.dispatchStatusEventAsync(AdEvent.onInterstitialFailedReceive, "FULL_ADMOB_LEVEL");
					}



				});


	}







	public void showInterstitial() {

			if (interstitial != null) {
				interstitial.show(context.getActivity());
			}
	}












}

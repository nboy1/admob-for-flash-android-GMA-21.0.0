build.xml  ant script
libclang_rt.ios.a copied from mac xcode sdk clang,you may need update it 
you need download the last admob sdk and update config files 